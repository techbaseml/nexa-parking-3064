import {defineConfig} from 'vite';
export default defineConfig({
 base:'./',
 server:{host:'0.0.0.0',allowedHosts:['terminal.local']},
 build:{rollupOptions:{output:{manualChunks:{three:['three'],physics:['@dimforge/rapier3d-compat']}}}}
});
